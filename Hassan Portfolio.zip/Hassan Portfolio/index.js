

var resp = prompt('PLEASE ENTER YOUR NAME:');

function makeMoreExciting(string) {
	return string + '!!!';
}
function yellIt(string) {
  string = string.toUpperCase();
  string = makeMoreExciting(string);
  console.log(string);
} 

yellIt("Hello!");
console.log(resp);

element = document.getElementById(note);
document.getElementById("note").innerHTML =
"Thank You";